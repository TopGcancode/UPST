import React from 'react';
import { ArrowLeft, Users, Award, Globe } from 'lucide-react';

interface AboutUsProps {
  onBack: () => void;
}

export default function AboutUs({ onBack }: AboutUsProps) {
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={onBack}
          className="flex items-center text-rose-600 hover:text-rose-700 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Home
        </button>
        
        <div className="text-center mb-16">
          <img 
            src="/O2_LOGO copy copy copy.png" 
            alt="OfficetoFlex" 
            className="mx-auto h-24 w-auto mb-8"
          />
          <h1 className="text-4xl font-bold text-slate-900 mb-6">About OfficetoFlex</h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Revolutionizing professional fashion through sustainable luxury rental services
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-16">
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-6">Our Mission</h2>
            <p className="text-slate-700 text-lg leading-relaxed mb-6">
              OfficetoFlex was founded with a simple yet powerful vision: to make luxury fashion accessible, sustainable, and flexible for the modern professional. We believe that everyone deserves to look and feel their best, whether in the boardroom or at special events.
            </p>
            <p className="text-slate-700 text-lg leading-relaxed">
              Our curated collection of designer pieces allows you to express your personal style while making environmentally conscious choices. By renting instead of buying, you're contributing to a more sustainable fashion future.
            </p>
          </div>
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-6">Our Story</h2>
            <p className="text-slate-700 text-lg leading-relaxed mb-6">
              Founded in 2024, OfficetoFlex emerged from the recognition that professional wardrobes needed to evolve. Traditional fashion retail wasn't meeting the needs of dynamic professionals who required versatile, high-quality clothing for various occasions.
            </p>
            <p className="text-slate-700 text-lg leading-relaxed">
              We partnered with luxury designers and fashion houses to create an exclusive rental platform that bridges the gap between professional necessity and personal style expression.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="text-center">
            <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-rose-600" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-2">Customer-Centric</h3>
            <p className="text-slate-600">
              Every decision we make is guided by our commitment to exceptional customer experience and satisfaction.
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-rose-600" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-2">Quality First</h3>
            <p className="text-slate-600">
              We maintain the highest standards in garment selection, care, and presentation to ensure luxury experiences.
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Globe className="w-8 h-8 text-rose-600" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-2">Sustainability</h3>
            <p className="text-slate-600">
              Promoting circular fashion and reducing environmental impact through shared luxury experiences.
            </p>
          </div>
        </div>

        <div className="bg-slate-50 rounded-2xl p-8 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Company Information</h2>
          <div className="grid md:grid-cols-2 gap-8 text-left max-w-2xl mx-auto">
            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Business Address:</h3>
              <p className="text-slate-700">
                OfficetoFlex LLC<br />
                [Your Business Address]<br />
                [City, State, ZIP Code]
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Contact Information:</h3>
              <p className="text-slate-700">
                Email: info@officetoflex.com<br />
                Phone: [Your Phone Number]<br />
                Business Hours: Mon-Fri 9AM-6PM EST
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}