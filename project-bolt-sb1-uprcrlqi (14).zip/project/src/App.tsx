import React, { useState } from 'react';
import { Mail, Calendar, Sparkles, Users, ArrowRight, CheckCircle2, Crown, Gem } from 'lucide-react';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsOfService from './components/TermsOfService';
import AboutUs from './components/AboutUs';
import CheckoutForm from './components/CheckoutForm';

function App() {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [currentPage, setCurrentPage] = useState<'home' | 'privacy' | 'terms' | 'about' | 'checkout'>('home');
  const [selectedItem, setSelectedItem] = useState<any>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubmitted(true);
      setEmail('');
    }
  };

  const handleCheckout = (item: any) => {
    setSelectedItem(item);
    setCurrentPage('checkout');
  };

  if (currentPage === 'privacy') {
    return <PrivacyPolicy onBack={() => setCurrentPage('home')} />;
  }

  if (currentPage === 'terms') {
    return <TermsOfService onBack={() => setCurrentPage('home')} />;
  }

  if (currentPage === 'about') {
    return <AboutUs onBack={() => setCurrentPage('home')} />;
  }

  if (currentPage === 'checkout' && selectedItem) {
    return <CheckoutForm item={selectedItem} onBack={() => setCurrentPage('home')} />;
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="w-full h-full object-cover"
        >
          <source src="https://videos.pexels.com/video-files/6195149/6195149-uhd_2560_1440_25fps.mp4" type="video/mp4" />
        </video>
        {/* Elegant overlay for better text readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-black/60"></div>
      </div>

      {/* Header */}
      <header className="relative z-20 px-4 py-6 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img 
              src="/O2_LOGO copy copy copy.png" 
              alt="OfficetoFlex" 
              className="h-16 w-auto drop-shadow-lg"
            />
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-20">
          <div className="text-center">
            {/* Large centered logo */}
            <div className="mb-12">
              <img 
                src="/O2_LOGO copy copy copy.png" 
                alt="OfficetoFlex" 
                className="mx-auto h-48 sm:h-56 lg:h-72 w-auto drop-shadow-2xl"
              />
            </div>
            
            <div className="inline-flex items-center px-6 py-3 rounded-full bg-white/95 backdrop-blur-sm text-rose-800 text-sm font-medium mb-8 shadow-xl">
              <Sparkles className="w-4 h-4 mr-2" />
              Professional to Flexible Fashion
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6 drop-shadow-2xl">
              From
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-400 to-pink-600"> Office</span>
              <br />
              toFlex
            </h1>
            
            <p className="text-xl text-white/95 max-w-3xl mx-auto mb-12 leading-relaxed drop-shadow-lg">
              Transform your professional wardrobe into flexible, stylish pieces perfect for any occasion. 
              Rent premium clothing that transitions seamlessly from boardroom to social events.
            </p>

            {/* Waitlist Form */}
            <div className="max-w-md mx-auto mb-16">
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
                  <div className="flex-1">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email for early access"
                      required
                      className="w-full px-5 py-4 rounded-xl border border-white/20 bg-white/95 backdrop-blur-sm focus:border-rose-500 focus:ring-2 focus:ring-rose-200 outline-none transition-all duration-200 text-slate-900 placeholder-slate-500"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-8 py-4 bg-gradient-to-r from-rose-500 to-pink-600 text-white rounded-xl font-semibold hover:from-rose-600 hover:to-pink-700 transition-all duration-200 flex items-center justify-center gap-2 shadow-xl hover:shadow-2xl transform hover:scale-105"
                  >
                    Join Waitlist
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </form>
              ) : (
                <div className="flex items-center justify-center space-x-3 text-rose-700 bg-white/95 backdrop-blur-sm px-8 py-5 rounded-xl shadow-xl">
                  <CheckCircle2 className="w-6 h-6" />
                  <span className="font-semibold">Welcome to luxury! We'll be in touch soon.</span>
                </div>
              )}
            </div>

            {/* Social Proof */}
            <div className="flex items-center justify-center space-x-2 text-white/80 mb-20">
              <Users className="w-5 h-5" />
              <span className="text-sm">Join 5,000+ fashion enthusiasts on the waitlist</span>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="bg-white py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Logo in Features Section */}
            <div className="text-center mb-12">
              <img 
                src="/O2_LOGO copy copy copy.png" 
                alt="OfficetoFlex" 
                className="mx-auto h-20 w-auto opacity-80"
              />
            </div>
            
            <div className="text-center mb-20">
              <h2 className="text-4xl font-bold text-slate-900 mb-6">
                Luxury Fashion, Redefined
              </h2>
              <p className="text-xl text-slate-600 max-w-3xl mx-auto">
                Experience haute couture and designer fashion like never before with our premium rental service
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-12">
              <div className="text-center group">
                <div className="w-20 h-20 bg-gradient-to-br from-rose-500 to-pink-600 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                  <Crown className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Designer Collections</h3>
                <p className="text-slate-600 leading-relaxed text-lg">
                  Curated pieces from Chanel, Dior, Valentino, and other luxury houses. Access runway looks and exclusive designs.
                </p>
              </div>

              <div className="text-center group">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                  <Sparkles className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Perfect Fit Guarantee</h3>
                <p className="text-slate-600 leading-relaxed text-lg">
                  Professional styling consultation and alterations included. Look flawless for galas, weddings, and special events.
                </p>
              </div>

              <div className="text-center group">
                <div className="w-20 h-20 bg-gradient-to-br from-amber-500 to-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                  <Gem className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">White Glove Service</h3>
                <p className="text-slate-600 leading-relaxed text-lg">
                  Concierge delivery, professional cleaning, and insurance included. Luxury service from start to finish.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Designer Fashion Gallery */}
        <div className="bg-slate-50 py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-slate-900 mb-6">
                Style That Speaks Volumes
              </h2>
              <p className="text-xl text-slate-600 max-w-3xl mx-auto">
                See how our curated designer pieces transform everyday moments into extraordinary experiences
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
              <div className="group relative overflow-hidden rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300">
                <img
                  src="https://images.pexels.com/photos/1462637/pexels-photo-1462637.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Elegant Black woman in designer outfit"
                  className="w-full h-96 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute bottom-4 left-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="font-semibold">Sophisticated Style</p>
                  <p className="text-sm text-white/80">Designer evening wear</p>
                </div>
              </div>

              <div className="group relative overflow-hidden rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300">
                <img
                  src="https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Professional Asian woman in designer blazer"
                  className="w-full h-96 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute bottom-4 left-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="font-semibold">Executive Power</p>
                  <p className="text-sm text-white/80">Professional blazer collection</p>
                </div>
              </div>

              <div className="group relative overflow-hidden rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300">
                <img
                  src="https://images.pexels.com/photos/1183266/pexels-photo-1183266.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Stylish Latina woman in designer dress"
                  className="w-full h-96 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute bottom-4 left-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="font-semibold">Versatile Elegance</p>
                  <p className="text-sm text-white/80">Day-to-night collection</p>
                </div>
              </div>
            </div>

            {/* Designer Pieces with Pricing */}
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-slate-900 mb-4">Featured Designer Pieces</h3>
              <p className="text-lg text-slate-600">Premium fashion at accessible weekly rates</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
                <img
                  src="https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Chanel-style blazer"
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="p-6">
                  <h4 className="font-bold text-slate-900 mb-2">Chanel-Style Blazer</h4>
                  <p className="text-slate-600 text-sm mb-3">Classic tweed blazer with gold buttons</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-rose-600">$45</span>
                    <span className="text-slate-500 text-sm">/week</span>
                  </div>
                  <button
                    onClick={() => handleCheckout({
                      name: 'Chanel-Style Blazer',
                      price: 45,
                      image: 'https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=800',
                      description: 'Classic tweed blazer with gold buttons'
                    })}
                    className="w-full bg-rose-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-rose-700 transition-colors"
                  >
                    Rent Now
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
                <img
                  src="https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Valentino-style dress"
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="p-6">
                  <h4 className="font-bold text-slate-900 mb-2">Valentino-Style Dress</h4>
                  <p className="text-slate-600 text-sm mb-3">Elegant midi dress with lace details</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-rose-600">$38</span>
                    <span className="text-slate-500 text-sm">/week</span>
                  </div>
                  <button
                    onClick={() => handleCheckout({
                      name: 'Valentino-Style Dress',
                      price: 38,
                      image: 'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=800',
                      description: 'Elegant midi dress with lace details'
                    })}
                    className="w-full bg-rose-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-rose-700 transition-colors"
                  >
                    Rent Now
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
                <img
                  src="https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Armani-style suit"
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="p-6">
                  <h4 className="font-bold text-slate-900 mb-2">Armani-Style Suit</h4>
                  <p className="text-slate-600 text-sm mb-3">Tailored wool suit with modern cut</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-rose-600">$50</span>
                    <span className="text-slate-500 text-sm">/week</span>
                  </div>
                  <button
                    onClick={() => handleCheckout({
                      name: 'Armani-Style Suit',
                      price: 50,
                      image: 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=800',
                      description: 'Tailored wool suit with modern cut'
                    })}
                    className="w-full bg-rose-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-rose-700 transition-colors"
                  >
                    Rent Now
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
                <img
                  src="https://images.pexels.com/photos/1183266/pexels-photo-1183266.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Dior-style cocktail dress"
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="p-6">
                  <h4 className="font-bold text-slate-900 mb-2">Dior-Style Cocktail Dress</h4>
                  <p className="text-slate-600 text-sm mb-3">Sophisticated evening wear with silk finish</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-rose-600">$42</span>
                    <span className="text-slate-500 text-sm">/week</span>
                  </div>
                  <button
                    onClick={() => handleCheckout({
                      name: 'Dior-Style Cocktail Dress',
                      price: 42,
                      image: 'https://images.pexels.com/photos/1183266/pexels-photo-1183266.jpeg?auto=compress&cs=tinysrgb&w=800',
                      description: 'Sophisticated evening wear with silk finish'
                    })}
                    className="w-full bg-rose-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-rose-700 transition-colors"
                  >
                    Rent Now
                  </button>
                </div>
              </div>
            </div>

            <div className="text-center mt-12">
              <p className="text-slate-600 text-lg">
                All pieces include professional cleaning, insurance, and styling consultation
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-slate-900 via-rose-900 to-slate-900 py-24">
          <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
            {/* Logo in CTA Section */}
            <div className="mb-8">
              <img 
                src="/O2_LOGO copy copy copy.png" 
                alt="OfficetoFlex" 
                className="mx-auto h-24 w-auto drop-shadow-xl filter brightness-0 invert"
              />
            </div>
            
            <h2 className="text-4xl sm:text-5xl font-bold text-white mb-8">
              Your Designer Wardrobe Awaits
            </h2>
            <p className="text-xl text-rose-100 mb-10 max-w-3xl mx-auto leading-relaxed">
              Join the exclusive world of luxury fashion rental. Be the first to access our curated collection of designer pieces.
            </p>
            <div className="flex flex-wrap justify-center gap-6 text-rose-200">
              <span className="flex items-center gap-2 text-lg">
                <CheckCircle2 className="w-5 h-5" />
                VIP early access
              </span>
              <span className="flex items-center gap-2 text-lg">
                <CheckCircle2 className="w-5 h-5" />
                Exclusive member pricing
              </span>
              <span className="flex items-center gap-2 text-lg">
                <CheckCircle2 className="w-5 h-5" />
                Personal styling service
              </span>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center space-y-8">
            {/* Footer Navigation */}
            <div className="flex flex-wrap justify-center gap-8 text-slate-300">
              <button
                onClick={() => setCurrentPage('about')}
                className="hover:text-white transition-colors"
              >
                About Us
              </button>
              <button
                onClick={() => setCurrentPage('privacy')}
                className="hover:text-white transition-colors"
              >
                Privacy Policy
              </button>
              <button
                onClick={() => setCurrentPage('terms')}
                className="hover:text-white transition-colors"
              >
                Terms of Service
              </button>
              <a
                href="mailto:info@officetoflex.com"
                className="hover:text-white transition-colors"
              >
                Contact Us
              </a>
            </div>
            
            {/* Footer Navigation */}
            <div className="flex flex-wrap justify-center gap-8 text-slate-300">
              <button
                onClick={() => setCurrentPage('about')}
                className="hover:text-white transition-colors"
              >
                About Us
              </button>
              <button
                onClick={() => setCurrentPage('privacy')}
                className="hover:text-white transition-colors"
              >
                Privacy Policy
              </button>
              <button
                onClick={() => setCurrentPage('terms')}
                className="hover:text-white transition-colors"
              >
                Terms of Service
              </button>
              <a
                href="mailto:info@officetoflex.com"
                className="hover:text-white transition-colors"
              >
                Contact Us
              </a>
            </div>
            
            {/* Company Info */}
            <div className="flex items-center space-x-3 mb-6 md:mb-0">
              <img 
                src="/O2_LOGO copy copy copy.png" 
                alt="OfficetoFlex" 
                className="h-12 w-auto opacity-80"
              />
            </div>
            
            {/* Legal Text */}
            <div className="text-slate-400 text-center space-y-2">
              <p>© 2024 OfficetoFlex. Professional fashion rental reimagined.</p>
              <p className="text-sm mt-1">Coming soon to select cities worldwide.</p>
              <div className="text-xs space-y-1">
                <p>OfficetoFlex™ is a trademark of OfficetoFlex LLC</p>
                <p>All designer brands and logos are property of their respective owners</p>
                <p>Business Registration: [Your Business Registration Number]</p>
                <p>Tax ID: [Your Tax ID Number]</p>
                <p>Licensed Fashion Rental Service Provider</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;